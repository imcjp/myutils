# myutils
nginxProj的部署命令：

curl -s https://raw.githubusercontent.com/imcjp/myutils/refs/heads/main/nginxProj/setup.sh | bash
