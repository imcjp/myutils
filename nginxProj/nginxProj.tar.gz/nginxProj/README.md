# myutils
FATE框架的部署命令：

curl -s https://raw.githubusercontent.com/imcjp/myutils/main/frpcDeploy/setup.sh | bash
