#!/bin/bash

bin_path="$(dirname "${BASH_SOURCE[0]}")"

bash ${bin_path}/mount dev
